import ApolloClient from 'apollo-boost';

export const apolloClient = new ApolloClient({
    uri: "https://fcg-fe-test.herokuapp.com/"
});