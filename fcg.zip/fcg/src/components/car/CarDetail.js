import React from "react";

export default function CarDetail(){
    return (
        <footer>
            <div className="footer-wrapper">
                <span>© 2018 MEDWING GmbH, Berlin. Alle Rechte vorbehalten.</span>
            </div>
        </footer>
    );
}
