import React from "react";

export default function FooterCmp(){
    return (
        <footer>
            <div className="footer-wrapper">
                <span>© 2018 MEDWING GmbH, Berlin. Alle Rechte vorbehalten.</span>
            </div>
        </footer>
    );
}
