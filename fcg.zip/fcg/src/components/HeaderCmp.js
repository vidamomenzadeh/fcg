'use strict';

import React from 'react';

export default function HeaderCmp(){

    return(
        <div className="header-wrapper">
            <div className="header-elements">

            </div>
        </div>

    );
}

