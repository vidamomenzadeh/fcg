import {Modal} from "antd";

export default function TasksForm(props){
    return( <Modal
        visible={true}
        title="A Form to add information"
    >
    </Modal>)
}